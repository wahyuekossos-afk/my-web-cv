---
name: Creative Professional CV System
colors:
  surface: '#fdf8f8'
  surface-dim: '#ddd9d8'
  surface-bright: '#fdf8f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f3f2'
  surface-container: '#f1edec'
  surface-container-high: '#ebe7e6'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#444748'
  inverse-surface: '#313030'
  inverse-on-surface: '#f4f0ef'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#5d5f5f'
  on-secondary: '#ffffff'
  secondary-container: '#dcdddd'
  on-secondary-container: '#5f6161'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1d1b1a'
  on-tertiary-container: '#868381'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474646'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#e6e1df'
  tertiary-fixed-dim: '#cac6c3'
  on-tertiary-fixed: '#1d1b1a'
  on-tertiary-fixed-variant: '#484645'
  background: '#fdf8f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  h1:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  h2:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  h3:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.0'
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1120px
  gutter: 32px
  section-padding: 80px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style

The design system is engineered for the high-end digital specialist who operates at the intersection of corporate reliability and creative innovation. It utilizes a **Minimalist-Glassmorphic** hybrid style, prioritizing extreme clarity through expansive whitespace and premium material effects. 

The aesthetic is characterized by high-contrast focal points—where deep blacks meet a piercing vibrant red—balanced by soft, translucent surfaces. This approach evokes a sense of "digital craftsmanship," signaling to recruiters and clients that the individual is both a disciplined professional and a forward-thinking creator.

## Colors

This design system employs a sophisticated tri-color palette. **Deep Black (#111111)** serves as the foundation for structural elements and primary typography, ensuring maximum legibility and a grounded feel. **Light Grey (#F5F5F5)** is used for secondary backgrounds and subtle sectioning to prevent visual fatigue.

**Vibrant Red (#FF4D4D)** is the system's "Energy Point." It is used sparingly for critical calls-to-action, interactive states, and stylistic highlights to guide the eye toward key achievements. The background is kept pure white to enhance the "gallery" feel of the portfolio content.

## Typography

The typography strategy leverages **Plus Jakarta Sans** for headlines to provide a modern, slightly geometric personality that feels fresh and tech-forward. High-level headings use aggressive negative letter-spacing and heavy weights to create a commanding presence.

**Inter** is utilized for all body and descriptive text. Its utilitarian nature ensures that long-form project descriptions and technical skills remain highly readable across all device sizes. Using uppercase labels with increased letter-spacing provides a clear architectural hierarchy for section headers and dates.

## Layout & Spacing

This design system follows a **Fixed-Grid model** within a centered 1120px container, optimized for desktop PDF export and web viewing. It utilizes a 12-column grid with generous 32px gutters to allow the content to "breathe."

The spacing rhythm is built on an 8px base unit. Large vertical section padding (80px+) is encouraged to separate distinct career phases or skill groups, reinforcing the premium, high-end vibe through intentional "waste" of space.

## Elevation & Depth

Depth is conveyed through **subtle glassmorphism** and extra-diffused ambient shadows. Floating elements, such as the contact sidebar or floating navigation, should use a backdrop filter (blur: 12px) with a semi-transparent white fill and a very thin (1px) white stroke to simulate a glass edge.

Shadows must be "soft-touch"—using high blur radii (20px-40px) with very low opacity (3-5%) to avoid a muddy appearance. This creates a layered UI where the content feels light and physically present.

## Shapes

The shape language is defined by the **16px (1rem) corner radius**. This applies to all primary containers, cards, and input fields. The consistent use of "Rounded-LG" (1rem) across the system softens the high-contrast color palette, making the professional content feel approachable and modern. 

Interactive elements like buttons use a slightly higher radius or full pill-shape to distinguish them from structural content blocks.

## Components

### Buttons
Primary buttons are solid **Deep Black** with white text, featuring 16px rounded corners. For creative emphasis, a "ghost" variant with a thin black border and a **Vibrant Red** hover state is used.

### Cards & Content Blocks
Cards utilize the subtle glassmorphism effect for secondary information. They feature a 1px `glass_stroke_hex` border. Large whitespace (24px-32px internal padding) is mandatory for card content.

### Skill Chips
Skills are represented by pill-shaped chips with a **Light Grey** background and **Deep Black** text. Expert-level skills are highlighted with a 2px **Vibrant Red** left-border or dot indicator.

### Experience Timeline
A minimalist vertical line (2px, Light Grey) with **Vibrant Red** nodes marks chronological milestones. This provides a clear visual path through the professional's history.

### Inputs
Search or contact fields are minimalist with a soft 1px border. On focus, the border transitions to the **Vibrant Red** accent color with a subtle outer glow.